
import React from 'react';

const BackgroundDecorations: React.FC = () => {
  // Trả về null để xóa chữ ST event màu vàng
  return null;
};

export default BackgroundDecorations;
