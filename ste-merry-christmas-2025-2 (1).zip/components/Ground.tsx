
import React from 'react';

const Ground: React.FC = () => {
  // Trả về null để xóa bỏ hoàn toàn tấm plane sàn màu đỏ và vòng nhẫn trang trí
  return null;
};

export default Ground;
