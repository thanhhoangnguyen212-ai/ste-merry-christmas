
import React from 'react';
import { AppMode } from '../types';

const TextHighlight: React.FC<{ mode: AppMode }> = ({ mode }) => {
  // Trả về null để xóa bỏ các vệt sáng chạy quanh chữ theo yêu cầu của người dùng
  return null;
};

export default TextHighlight;
