
export const initAudioContext = () => null;
export const resumeAudioContext = () => {};
export const playMagicalChime = () => {};
export const playSantaLaugh = () => {};
export const playSantaGreeting = () => {};
export const startAmbientLoops = () => {};
